package Controllers;

import Models.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBAccess {

    private Connection con;
    private Statement stmt;
    private void connect() throws SQLException{
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","");
        stmt = con.createStatement();
    }
    private void close() throws SQLException{
        stmt.close();
        con.close();
    }
    public void addDoctor(doctor Doctor){
        String query;
        query = "INSERT INTO doctor VALUES("
                + Doctor.getdoctorid() + ",'"
                + Doctor.getFirst_Name() + "','"
                + Doctor.getLast_Name() + "','"
                + Doctor.getSpeciality() + "',"
                + Doctor.getSalary() + ");";
        try{
            connect();
            stmt.executeUpdate(query);
            close();
        }
        catch(SQLException ex){
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void deleteDoctorById(int doctorid){
        String query;
        query = "DELETE FROM doctor WHERE doctorid=" + doctorid;
        try{
            connect();
            stmt.executeUpdate(query);
            close();
        }
        catch(SQLException ex){
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public patient getPatientById(int patientid){
        String query = "SELECT * FROM patient WHERE patientid=" + patientid;
        patient Patient = null;
        try{
            connect();
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                Patient = new patient();
                Patient.setPatient_Id(rs.getInt("patientid"));
                Patient.setFirst_Name(rs.getString("firstname"));
                Patient.setLast_Name(rs.getString("lastname"));
                Patient.setDoctorid(rs.getInt("doctorid"));
                Patient.setRoomid(rs.getInt("roomid"));                
            }
            close();
        }
        catch(SQLException ex){
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Patient;
    }
    public patient getPatientByFirstAndLastName(String firstname, String lastname){
        String query = "SELECT * FROM patient WHERE firstname=" + "'" + firstname + "'" + " AND lastname=" + "'" + lastname + "'";
        patient Patient = null;
        try{
            connect();
            ResultSet rs = stmt.executeQuery(query);
            if(rs.next()){
                Patient = new patient();
                Patient.setPatient_Id(rs.getInt("patientid"));
                Patient.setFirst_Name(rs.getString("firstname"));
                Patient.setLast_Name(rs.getString("lastname"));
                Patient.setDoctorid(rs.getInt("doctorid"));
                Patient.setRoomid(rs.getInt("roomid"));                
            }
            close();
        }
        catch(SQLException ex){
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Patient;
    }
    public void raiseSalary(int id) {
        String query;
        query = "UPDATE doctor SET salary=salary*0.1+salary WHERE doctorid=" + id;
        try {
            connect();
            stmt.executeUpdate(query);
            close();
        } catch (SQLException ex) {
            Logger.getLogger(DBAccess.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
