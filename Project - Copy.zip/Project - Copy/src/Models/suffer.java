package Models;

public class suffer {

    private int patientid;
    
    private String name;

    public suffer() {
    }

    public suffer(int Patient_Id, String Name) {
        this.patientid = Patient_Id;
        this.name = Name;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }


    public int getPatient_Id() {
        return patientid;
    }

    public void setPatient_Id(int Patient_Id) {
        this.patientid = Patient_Id;
    }

}
