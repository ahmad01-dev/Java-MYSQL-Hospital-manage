package Models;

public class doctor {

    private int doctorid;

    private String firstname;

    private String lastname;

    private String speciality;

    private int salary;

    public doctor() {
    }

    public doctor(int Doctor_Id, String First_Name, String Last_Name, String Speciality, int Salary) {
        this.doctorid = Doctor_Id;
        this.firstname = First_Name;
        this.lastname = Last_Name;
        this.speciality = Speciality;
        this.salary = Salary;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int Salary) {
        this.salary = Salary;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String Speciality) {
        this.speciality = Speciality;
    }

    public String getLast_Name() {
        return lastname;
    }

    public void setLast_Name(String Last_Name) {
        this.lastname = Last_Name;
    }

    public String getFirst_Name() {
        return firstname;
    }

    public void setFirst_Name(String First_Name) {
        this.firstname = First_Name;
    }

    public int getdoctorid() {
        return doctorid;
    }

    public void setDoctor_Id(int Doctor_Id) {
        this.doctorid = Doctor_Id;
    }

}
