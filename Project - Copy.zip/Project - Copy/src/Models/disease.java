package Models;

public class disease {

    private String name;

    private String type
;
    private String treatment;

    public disease() {
    }

    public disease(String Name, String Type, String Treatment) {
        this.name = Name;
        this.type = Type;
        this.treatment = Treatment;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String Treatment) {
        this.treatment = Treatment;
    }

    public String getType() {
        return type;
    }

    public void setType(String Type) {
        this.type = Type;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }

}
