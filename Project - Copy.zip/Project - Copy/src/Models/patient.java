package Models;

public class patient {

    private int patientid;

    private String firstname;

    private String lastname;

    private int doctorid;

    private int roomid;

    public int getRoomid() {
        return roomid;
    }

    public void setRoomid(int roomid) {
        this.roomid = roomid;
    }

    public int getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(int doctorid) {
        this.doctorid = doctorid;
    }

    public patient() {
    }

    public patient(int patientid, String firstname, String lastname, int doctorid, int roomid) {
        this.patientid = patientid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.doctorid = doctorid;
        this.roomid = roomid;
    }



    public String getLast_Name() {
        return lastname;
    }

    public void setLast_Name(String Last_Name) {
        this.lastname = Last_Name;
    }

    public String getFirst_Name() {
        return firstname;
    }

    public void setFirst_Name(String First_Name) {
        this.firstname = First_Name;
    }

    public int getPatient_Id() {
        return patientid;
    }

    public void setPatient_Id(int Patient_Id) {
        this.patientid = Patient_Id;
    }

}
