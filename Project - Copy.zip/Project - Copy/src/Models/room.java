package Models;

public class room {

    private int roomid;

    private int bedsnumber;

    public room() {
    }

    public room(int Room_Id, int Beds_Number) {
        this.roomid = Room_Id;
        this.bedsnumber = Beds_Number;
    }

    public int getBeds_Number() {
        return bedsnumber;
    }

    public void setBeds_Number(int Beds_Number) {
        this.bedsnumber = Beds_Number;
    }

    public int getRoom_Id() {
        return roomid;
    }

    public void setRoom_Id(int Room_Id) {
        this.roomid = Room_Id;
    }

}
